package rabbits;

public class Main {
}
